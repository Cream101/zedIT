import Nav from "@/components/Nav";
import Hero from "@/components/Hero";
import Projects from "@/components/Projects";
import Skills from "@/components/Skills";
import Education from "@/components/Education";
import Experience from "@/components/Experience";
import Certificates from "@/components/Certificates";
import References from "@/components/References";
import DigitalTwin from "@/components/DigitalTwin";
import Contact from "@/components/Contact";

export default function Home() {
  return (
    <>
      <Nav />
      <main className="mx-auto max-w-5xl px-5 sm:px-8">
        <Hero />
        <Projects />
        <Skills />
        <Education />
        <Experience />
        <Certificates />
        <References />
        <Contact />
      </main>
      <DigitalTwin />
    </>
  );
}
