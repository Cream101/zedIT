import { portfolio } from "@/data/portfolio";

const links = ["Projects", "Skills", "Education", "Experience", "Certificates", "References", "Contact"];

export default function Nav() {
  const [first, second] = portfolio.profile.name.split(" ");
  return (
    <header className="sticky top-0 z-50 border-b border-line bg-bg/90 backdrop-blur">
      <nav className="mx-auto flex max-w-5xl items-center justify-between gap-6 px-5 py-3 sm:px-8">
        <a href="#top" className="shrink-0 font-semibold hover:text-accent transition-colors">
          {first} {second}
        </a>
        <ul className="flex gap-5 overflow-x-auto text-sm text-muted">
          {links.map((l) => (
            <li key={l}>
              <a href={`#${l.toLowerCase()}`} className="hover:text-accent transition-colors">
                {l}
              </a>
            </li>
          ))}
        </ul>
      </nav>
    </header>
  );
}
